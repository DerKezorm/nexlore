BEGIN TRANSACTION;
CREATE TABLE accounts (
	id INTEGER NOT NULL, 
	name VARCHAR(64) NOT NULL, 
	display_name VARCHAR(80) NOT NULL, 
	whats_new_seen VARCHAR(32) NOT NULL, 
	notify JSON, 
	notify_webhook_enc TEXT NOT NULL, 
	notify_tasks_day VARCHAR(10) NOT NULL, 
	role VARCHAR(16) NOT NULL, 
	sign_in VARCHAR(16) NOT NULL, 
	password_hash VARCHAR(255) NOT NULL, 
	email VARCHAR(255) NOT NULL, 
	email_source VARCHAR(16) NOT NULL, 
	email_pending VARCHAR(255) NOT NULL, 
	email_pending_hash VARCHAR(64) NOT NULL, 
	email_pending_until DATETIME, 
	provider_email VARCHAR(255) NOT NULL, 
	provider_email_off VARCHAR(255) NOT NULL, 
	oidc_subject VARCHAR(255) NOT NULL, 
	language VARCHAR(16) NOT NULL, 
	created_at DATETIME NOT NULL, 
	last_seen_at DATETIME, 
	failed_logins INTEGER NOT NULL, 
	locked_until DATETIME, 
	totp_secret_enc TEXT NOT NULL, 
	totp_recovery TEXT NOT NULL, 
	totp_last_step INTEGER NOT NULL, 
	ai_url VARCHAR(500) NOT NULL, 
	ai_model VARCHAR(200) NOT NULL, 
	ai_key_enc TEXT NOT NULL, 
	ai_active BOOLEAN NOT NULL, 
	avatar BLOB, 
	avatar_at DATETIME, 
	appearance JSON, 
	news_since DATETIME, 
	calendar_feed_hash VARCHAR(64), 
	PRIMARY KEY (id), 
	UNIQUE (name)
);
INSERT INTO "accounts" VALUES(1,'betrieb','Betrieb','1.16.0',NULL,'','','operator','password','$argon2id$v=19$m=1024,t=1,p=1$TQG7wg3f/vcI3t2MYtLk8Q$GyhzFSzxN7Mb5YWngdg59AzegWijNEeFfGLQ9MQWcBY','betrieb@example.com','own','','',NULL,'','','','de','2026-11-24 19:59:37.787687','2026-11-24 19:59:41.501214',0,NULL,'77adeae00cd87caedb24ffb51c9c63a716ce8a6cdbb0307e505aebfbe5fad6db25e7dc336dc12d0eebb02eefb45195531b38b8e21a4e3a94401ac37f','["e040b90f1e0f5c706886877aa3abb811d78a0fed0aa381fe13952b4c77cfe777", "381c34dec6252f79f06ea8273d17c4a85a2e6c0aa595192f48907ddc7a4ec97e", "225ab459f55927a79fcc600d3058e82eecad2cffdcc18e61a5f22f98164eda50", "2a5e403781cdb5812b9ed9586433420a055d672589e66ab4ea80e4a6da81f367", "2a4c4f2d20dc84e7e03149166c3883a75a2048d3697adce34271df46602790a5", "379af3e21e6d14548174f1609f3d8e32b6a8f721b8f93c26bc3930f0305f3062", "f871a43f9ff4bcdbf3f27dae62397746bee942cefe6a1c4c56bc20eb7931e545", "5a2c02e3e6f198429ff62e8c1ad828fc634068421bb29a1eb1b84deb38156c1f"]',59851679,'','','',0,NULL,NULL,NULL,NULL,NULL);
INSERT INTO "accounts" VALUES(2,'erika-muster','','1.16.0',NULL,'','','member','password','$argon2id$v=19$m=1024,t=1,p=1$+FbQBxsIYNBluAaQ0lMm8Q$W8RvWW9kUOZUO9DAP9huyZdXW9NVUuyQBC2Gsw2kzng','','','erika@example.com','bb251e3de680e0be1c53d7e61b43620084c33926caa9fdfe5ff46900f9cab53f','2026-11-25 19:59:41.661714','','','','','2026-11-24 19:59:38.426219','2026-11-24 19:59:38.431014',0,NULL,'','',0,'','','',0,NULL,NULL,NULL,NULL,NULL);
INSERT INTO "accounts" VALUES(3,'jonas','Jonas Beispiel','1.16.0',NULL,'','','member','password','$argon2id$v=19$m=1024,t=1,p=1$1gae7UrniRrOZ+NdnyaBaw$rchHGbukNV8aYSxPjId0oIZNk9di+EyfKrjVYH8GnrE','jonas@example.com','invite','','',NULL,'','','','','2026-11-24 19:59:38.495248','2026-11-24 19:59:38.509248',0,NULL,'','',0,'','','',0,NULL,NULL,NULL,NULL,NULL);
INSERT INTO "accounts" VALUES(4,'kim','','1.16.0',NULL,'','','member','password','$argon2id$v=19$m=1024,t=1,p=1$frXbPrUMl1LPDQnkHbbrXQ$ueS0omYULJECXU6HCgnSgsJiJta0r4sVKvgSN0pULIY','Kim@Example.org','operator','','',NULL,'','','','','2026-11-24 19:59:38.602060','2026-11-24 19:59:38.606771',0,NULL,'','',0,'','','',0,NULL,NULL,NULL,NULL,NULL);
INSERT INTO "accounts" VALUES(5,'lou','','1.16.0',NULL,'','','member','password','$argon2id$v=19$m=1024,t=1,p=1$TUKVPYytCDy/iXfImjjFJg$b15CtPylB9zxLuLvOUuFEzdZNsuBWEvdZX0FQVfiy7E','kim@example.org','operator','','',NULL,'','','','','2026-11-24 19:59:38.670219','2026-11-24 19:59:38.674870',0,NULL,'','',0,'','','',0,NULL,NULL,NULL,NULL,NULL);
INSERT INTO "accounts" VALUES(6,'mona','','1.16.0',NULL,'','','member','password','$argon2id$v=19$m=1024,t=1,p=1$UpHXUlPSBZ5HBOxnEo5t4A$4fB9cY2wsRbj9N7MGD9RhKXzGvyMJ1IEsihLBv0eieU','','','','',NULL,'','','','','2026-11-24 19:59:38.770591','2026-11-24 19:59:38.864195',0,NULL,'e95b8a169eb772cde9e97fab38eaff2ad986ad9649bb8ebb3daed6a480f4a4761d767f10f682e62fcaaf0a42296f2c7507fb29bf7bf1ad4178a62983','["91503f89b9a82e4c4c2dd5e14b70d9698529b148052db310d6dc513803f4e030", "52fcd1c9b617d04b46a992a0fe60ee6aa8365fff9037b7277ff6f461c82d61fc", "c27df958ff66399116260b6f53cf835077230f2a9036932ec7494094354e17dc", "0ad944c86a387c84c69a42105d24b4516494ac6fb0f64160702ad8240f194516", "88d0b34c8c162d779531f81303be88bef29b09d651dbc916899f90e887b3536a", "109b3e8a5709083ea56791e3bdebd683e9ad6f5513286b37e758cdd311395d8b", "56b05e6e3d808069d5819c4007b5ac852da161f72ea72449b8593260662c7d8b", "e4cbb082bc1c891ce0212309607e2700c1bfb7dcbd360de97d3e15a0ef91cb86"]',59851679,'','','',0,NULL,NULL,NULL,'2026-11-24 19:59:39.456331',NULL);
INSERT INTO "accounts" VALUES(7,'sam','','1.16.0',NULL,'','','member','password','$argon2id$v=19$m=1024,t=1,p=1$qGBFXxqQBfn+E944tD70sQ$aBidamL5PgZy1fVWMTKfTXUwFPl1MKrdcG0OWQ/svTQ','sam@example.net','provider','','',NULL,'sam@example.net','','','','2026-11-24 19:59:40.159995','2026-11-24 19:59:40.203174',0,NULL,'','',0,'','','',0,NULL,NULL,NULL,NULL,NULL);
INSERT INTO "accounts" VALUES(8,'robin.sso','','1.16.0',NULL,'','','operator','oidc','','robin@example.net','provider','','',NULL,'robin@example.net','','','','2026-11-24 19:59:40.586578','2026-11-24 19:59:40.605066',0,NULL,'','',0,'','','',0,NULL,NULL,NULL,NULL,NULL);
INSERT INTO "accounts" VALUES(9,'max','','1.16.0',NULL,'','','member','oidc','','max@example.net','provider','','',NULL,'max@example.net','','','','2026-11-24 19:59:40.929446','2026-11-24 19:59:40.960502',0,NULL,'','',0,'','','',0,NULL,NULL,NULL,NULL,NULL);
CREATE TABLE ai_events (
	id INTEGER NOT NULL, 
	account_id INTEGER NOT NULL, 
	at DATETIME NOT NULL, 
	model VARCHAR(200) NOT NULL, 
	task VARCHAR(32) NOT NULL, 
	target VARCHAR(64) NOT NULL, 
	body_enc TEXT NOT NULL, 
	tokens_in INTEGER NOT NULL, 
	tokens_out INTEGER NOT NULL, 
	error VARCHAR(64) NOT NULL, 
	PRIMARY KEY (id), 
	FOREIGN KEY(account_id) REFERENCES accounts (id) ON DELETE CASCADE
);
CREATE TABLE api_tokens (
	id INTEGER NOT NULL, 
	account_id INTEGER NOT NULL, 
	name VARCHAR(100) NOT NULL, 
	level VARCHAR(8) NOT NULL, 
	token_hash VARCHAR(64) NOT NULL, 
	prefix VARCHAR(16) NOT NULL, 
	spaces JSON, 
	created_at DATETIME NOT NULL, 
	last_used_at DATETIME, 
	expires_at DATETIME, 
	blocked_at DATETIME, 
	warned_at DATETIME, 
	PRIMARY KEY (id), 
	FOREIGN KEY(account_id) REFERENCES accounts (id) ON DELETE CASCADE, 
	UNIQUE (token_hash)
);
INSERT INTO "api_tokens" VALUES(1,3,'Git-Spiegel','read','bcfb1772bc23f9a0dc67e3c7b2dbb9c2be22a51c7a1cd5c6b50dd82296a61913','nxa_best','null','2026-11-24 19:59:39.953607',NULL,NULL,NULL,NULL);
CREATE TABLE app_devices (
	id INTEGER NOT NULL, 
	account_id INTEGER NOT NULL, 
	name VARCHAR(80) NOT NULL, 
	key_hash VARCHAR(64) NOT NULL, 
	created_at DATETIME NOT NULL, 
	last_seen_at DATETIME, 
	PRIMARY KEY (id), 
	FOREIGN KEY(account_id) REFERENCES accounts (id) ON DELETE CASCADE, 
	UNIQUE (key_hash)
);
INSERT INTO "app_devices" VALUES(1,6,'Monas iPhone','527dfbc3dd7b46526a87604df6337d34fd7e6a2357866183a2209f097ecf1044','2026-11-24 19:59:39.419619',NULL);
CREATE TABLE app_ops (
	device_id INTEGER NOT NULL, 
	op_id VARCHAR(64) NOT NULL, 
	result JSON NOT NULL, 
	created_at DATETIME NOT NULL, 
	PRIMARY KEY (device_id, op_id), 
	FOREIGN KEY(device_id) REFERENCES app_devices (id) ON DELETE CASCADE
);
CREATE TABLE app_pairings (
	id VARCHAR(32) NOT NULL, 
	account_id INTEGER NOT NULL, 
	secret_hash VARCHAR(64) NOT NULL, 
	code_hash VARCHAR(64) NOT NULL, 
	created_at DATETIME NOT NULL, 
	expires_at DATETIME NOT NULL, 
	used_at DATETIME, 
	device_name VARCHAR(80) NOT NULL, 
	PRIMARY KEY (id), 
	FOREIGN KEY(account_id) REFERENCES accounts (id) ON DELETE CASCADE
);
INSERT INTO "app_pairings" VALUES('bestand-mona-iphone-020-festwert',6,'8145829dc8b0edcf9da79516ecdb7cf2d2e311ef84cc8a20b563aa91e3ac555e','1a66c1e87357123fd06afd864c699c2515ec8d173cc6fd21e9900573bb382884','2026-11-24 19:59:39.318925','2026-11-24 20:09:39.318925','2026-11-24 19:59:39.406670','Monas iPhone');
CREATE TABLE auth_sessions (
	id INTEGER NOT NULL, 
	token_hash VARCHAR(64) NOT NULL, 
	account_id INTEGER NOT NULL, 
	created_at DATETIME NOT NULL, 
	expires_at DATETIME NOT NULL, 
	last_seen_at DATETIME NOT NULL, 
	ip VARCHAR(64) NOT NULL, 
	user_agent VARCHAR(255) NOT NULL, 
	via VARCHAR(16) DEFAULT 'password' NOT NULL, 
	PRIMARY KEY (id), 
	UNIQUE (token_hash), 
	FOREIGN KEY(account_id) REFERENCES accounts (id) ON DELETE CASCADE
);
INSERT INTO "auth_sessions" VALUES(1,'7498e84d7f96804861a118239eb026d3a7a7ece2b96c5b18fde2911280943c14',1,'2026-11-24 19:59:37.807583','2026-12-24 19:59:37.800798','2026-11-24 19:59:37.807595','testclient','testclient','password');
INSERT INTO "auth_sessions" VALUES(2,'8b9d660ac63ff71f7b8316bf17f4d0e7a48405e40434f766e2362b4fac5c6f9b',2,'2026-11-24 19:59:38.437309','2026-12-24 19:59:38.430904','2026-11-24 19:59:38.437319','testclient','testclient','password');
INSERT INTO "auth_sessions" VALUES(3,'aa939ae34350790cc8c318ca04ed4fc67010510e371734fac50fb87048a634c6',3,'2026-11-24 19:59:38.515123','2026-12-24 19:59:38.509056','2026-11-24 19:59:38.515134','testclient','testclient','password');
INSERT INTO "auth_sessions" VALUES(4,'f8ad80119f7d0261847460aa35d9612e2c65e17c5d886c4a0cf229acd4a01146',4,'2026-11-24 19:59:38.610700','2026-12-24 19:59:38.606562','2026-11-24 19:59:38.610710','testclient','testclient','password');
INSERT INTO "auth_sessions" VALUES(5,'9c861a9d375beb440a58eb91ea7a0f7a941a2ff2187f1c9da038c6143aab2f66',5,'2026-11-24 19:59:38.678136','2026-12-24 19:59:38.674778','2026-11-24 19:59:38.678140','testclient','testclient','password');
INSERT INTO "auth_sessions" VALUES(6,'40b4f5c3ca55890aceac6b810770efe7a94b01d0f208db3b831fccc46f835dcd',6,'2026-11-24 19:59:38.790287','2026-12-24 19:59:38.784431','2026-11-24 19:59:38.790300','testclient','testclient','password');
INSERT INTO "auth_sessions" VALUES(7,'1929f19061c7737c0380bffb019467f0eba9bd73132be23cebc583094d1f55c7',7,'2026-11-24 19:59:40.172652','2026-12-24 19:59:40.166717','2026-11-24 19:59:40.172659','testclient','testclient','password');
INSERT INTO "auth_sessions" VALUES(8,'c12458cad0388dc4603049993be59d5d49e747cc93c8e95214ea61f3e89d5846',8,'2026-11-24 19:59:40.605916','2026-12-24 19:59:40.604959','2026-11-24 19:59:40.605919','testclient','testclient','provider');
INSERT INTO "auth_sessions" VALUES(9,'8ec89f742d27bc63af858acdbf04291a085d05514ccdbcb1dd355900c672fea9',9,'2026-11-24 19:59:40.961344','2026-12-24 19:59:40.960330','2026-11-24 19:59:40.961351','testclient','testclient','provider');
CREATE TABLE comments (
	id INTEGER NOT NULL, 
	file_id INTEGER NOT NULL, 
	space_id INTEGER NOT NULL, 
	thread_id INTEGER, 
	account_id INTEGER, 
	author VARCHAR(64) NOT NULL, 
	body TEXT NOT NULL, 
	quote TEXT NOT NULL, 
	"before" VARCHAR(200) NOT NULL, 
	"after" VARCHAR(200) NOT NULL, 
	created_at DATETIME NOT NULL, 
	edited_at DATETIME, 
	resolved_at DATETIME, 
	resolved_by VARCHAR(64) NOT NULL, 
	PRIMARY KEY (id), 
	FOREIGN KEY(file_id) REFERENCES files (id) ON DELETE CASCADE, 
	FOREIGN KEY(space_id) REFERENCES spaces (id) ON DELETE CASCADE, 
	FOREIGN KEY(thread_id) REFERENCES comments (id) ON DELETE CASCADE, 
	FOREIGN KEY(account_id) REFERENCES accounts (id) ON DELETE SET NULL
);
INSERT INTO "comments" VALUES(1,1,1,NULL,3,'jonas','Was meinst du, @mona?','Ergänzt von Jonas','','.','2026-11-24 19:59:39.894998',NULL,NULL,'');
INSERT INTO "comments" VALUES(2,2,1,NULL,NULL,'weg','Die Leiter bringe ich mit.','Leiter','- ','','2026-11-24 19:59:41.427585',NULL,NULL,'');
CREATE TABLE css_snippets (
	id INTEGER NOT NULL, 
	account_id INTEGER NOT NULL, 
	name VARCHAR(80) NOT NULL, 
	css TEXT NOT NULL, 
	enabled BOOLEAN NOT NULL, 
	changed_at DATETIME NOT NULL, 
	PRIMARY KEY (id), 
	FOREIGN KEY(account_id) REFERENCES accounts (id) ON DELETE CASCADE
);
CREATE TABLE device_bases (
	device_id INTEGER NOT NULL, 
	file_id INTEGER NOT NULL, 
	hash VARCHAR(64) NOT NULL, 
	content BLOB NOT NULL, 
	updated_at DATETIME NOT NULL, 
	PRIMARY KEY (device_id, file_id), 
	FOREIGN KEY(device_id) REFERENCES app_devices (id) ON DELETE CASCADE, 
	FOREIGN KEY(file_id) REFERENCES files (id) ON DELETE CASCADE
);
CREATE TABLE drafts (
	id INTEGER NOT NULL, 
	account_id INTEGER NOT NULL, 
	key_id INTEGER, 
	key_name VARCHAR(100) NOT NULL, 
	space_id INTEGER NOT NULL, 
	file_id INTEGER, 
	path VARCHAR(1024) NOT NULL, 
	base_hash VARCHAR(64) NOT NULL, 
	content BLOB NOT NULL, 
	reason VARCHAR(500) NOT NULL, 
	created_at DATETIME NOT NULL, 
	PRIMARY KEY (id), 
	FOREIGN KEY(account_id) REFERENCES accounts (id) ON DELETE CASCADE, 
	FOREIGN KEY(space_id) REFERENCES spaces (id) ON DELETE CASCADE, 
	FOREIGN KEY(file_id) REFERENCES files (id) ON DELETE CASCADE
);
CREATE TABLE favorites (
	id INTEGER NOT NULL, 
	account_id INTEGER NOT NULL, 
	path VARCHAR(1024) NOT NULL, 
	section VARCHAR(80) NOT NULL, 
	PRIMARY KEY (id), 
	FOREIGN KEY(account_id) REFERENCES accounts (id) ON DELETE CASCADE
);
CREATE TABLE files (
	id INTEGER NOT NULL, 
	space_id INTEGER NOT NULL, 
	path VARCHAR(1024) NOT NULL, 
	path_key VARCHAR(1024) NOT NULL, 
	name_key VARCHAR(255) NOT NULL, 
	is_note BOOLEAN NOT NULL, 
	title VARCHAR(1024) NOT NULL, 
	size INTEGER NOT NULL, 
	mtime_ns INTEGER NOT NULL, 
	hash VARCHAR(64) NOT NULL, 
	front JSON, 
	features JSON, 
	indexed_at DATETIME NOT NULL, 
	deleted_at DATETIME, 
	deleted_how VARCHAR(16), 
	deleted_by VARCHAR(255), 
	trash_group VARCHAR(36), 
	owner VARCHAR(255), 
	cursor INTEGER NOT NULL, 
	PRIMARY KEY (id), 
	FOREIGN KEY(space_id) REFERENCES spaces (id) ON DELETE CASCADE
);
INSERT INTO "files" VALUES(1,1,'Projekt/Plan.md','projekt/plan.md','plan',1,'Plan',56,1795550379623384400,'71a3bc8aad4e492e1d5e00b4ad48045bb8745b53c42d26ba2d543848d9dada56','null','null','2026-11-24 19:59:39.627730',NULL,NULL,NULL,NULL,NULL,10);
INSERT INTO "files" VALUES(2,1,'Projekt/Liste.md','projekt/liste.md','liste',1,'Liste',29,1795550381318408100,'c4a0e687458143c01bd21acc275df6e8cd4f93de14b337edd1e23e52d74d68aa','null','null','2026-11-24 19:59:41.321679',NULL,NULL,NULL,NULL,NULL,13);
INSERT INTO "files" VALUES(3,1,'Projekt/Attachments/skizze.txt','projekt/attachments/skizze.txt','skizze.txt',0,'skizze.txt',32,1795550379818794000,'4f22a8cb898fc2e07ec1dfdd3e685dff87638262fb21aa9cf75656a2ac5feda0','null','null','2026-11-24 19:59:39.835317',NULL,NULL,NULL,NULL,'jonas',12);
CREATE TABLE gone_files (
	file_id INTEGER NOT NULL, 
	space_id INTEGER NOT NULL, 
	path VARCHAR(1024) NOT NULL, 
	cursor INTEGER NOT NULL, 
	gone_at DATETIME NOT NULL, 
	PRIMARY KEY (file_id)
);
CREATE TABLE graph_groups (
	id INTEGER NOT NULL, 
	space_id INTEGER NOT NULL, 
	cloud VARCHAR(8) NOT NULL, 
	"key" VARCHAR(1100) NOT NULL, 
	parent_id INTEGER, 
	kind VARCHAR(12) NOT NULL, 
	name VARCHAR(1024) NOT NULL, 
	anchor_id INTEGER, 
	total INTEGER NOT NULL, 
	daily INTEGER NOT NULL, 
	x FLOAT NOT NULL, 
	y FLOAT NOT NULL, 
	r FLOAT NOT NULL, 
	rx FLOAT NOT NULL, 
	ry FLOAT NOT NULL, 
	color INTEGER NOT NULL, 
	PRIMARY KEY (id), 
	UNIQUE (space_id, cloud, "key"), 
	FOREIGN KEY(space_id) REFERENCES spaces (id) ON DELETE CASCADE
);
CREATE TABLE graph_nodes (
	cloud VARCHAR(8) NOT NULL, 
	file_id INTEGER NOT NULL, 
	space_id INTEGER NOT NULL, 
	group_id INTEGER NOT NULL, 
	x FLOAT NOT NULL, 
	y FLOAT NOT NULL, 
	r FLOAT NOT NULL, 
	rx FLOAT NOT NULL, 
	ry FLOAT NOT NULL, 
	level INTEGER NOT NULL, 
	placed VARCHAR(1100) NOT NULL, 
	daily BOOLEAN NOT NULL, 
	PRIMARY KEY (cloud, file_id), 
	FOREIGN KEY(file_id) REFERENCES files (id) ON DELETE CASCADE, 
	FOREIGN KEY(space_id) REFERENCES spaces (id) ON DELETE CASCADE
);
CREATE TABLE graph_state (
	space_id INTEGER NOT NULL, 
	cloud VARCHAR(8) NOT NULL, 
	version INTEGER NOT NULL, 
	built_at DATETIME, 
	changed_at DATETIME, 
	placed_since INTEGER NOT NULL, 
	PRIMARY KEY (space_id, cloud), 
	FOREIGN KEY(space_id) REFERENCES spaces (id) ON DELETE CASCADE
);
CREATE TABLE invites (
	id INTEGER NOT NULL, 
	token_hash VARCHAR(64) NOT NULL, 
	space_id INTEGER, 
	space_role VARCHAR(16) NOT NULL, 
	email VARCHAR(255) NOT NULL, 
	created_by INTEGER, 
	created_at DATETIME NOT NULL, 
	expires_at DATETIME NOT NULL, 
	PRIMARY KEY (id), 
	UNIQUE (token_hash), 
	FOREIGN KEY(space_id) REFERENCES spaces (id) ON DELETE CASCADE, 
	FOREIGN KEY(created_by) REFERENCES accounts (id) ON DELETE SET NULL
);
INSERT INTO "invites" VALUES(1,'5589b6d41c963f60e654f8dac0881135118aeabee2bacce73d6b95d6d7b3db18',1,'read','neu@example.org',3,'2026-11-24 19:59:40.041436','2026-12-24 19:59:40.040966');
INSERT INTO "invites" VALUES(2,'6d5690b9d358f4ad6dd853aae4fe26f64b5db3777dae0d17b13745efc55a5537',NULL,'','offen@example.com',1,'2026-11-24 19:59:41.558127','2026-12-24 19:59:41.553405');
CREATE TABLE links (
	id INTEGER NOT NULL, 
	source_id INTEGER NOT NULL, 
	space_id INTEGER NOT NULL, 
	kind VARCHAR(16) NOT NULL, 
	target VARCHAR(1024) NOT NULL, 
	subpath VARCHAR(1024) NOT NULL, 
	target_key VARCHAR(255) NOT NULL, 
	target_id INTEGER, 
	line INTEGER NOT NULL, 
	via VARCHAR(255), 
	target_space_id INTEGER, 
	PRIMARY KEY (id), 
	FOREIGN KEY(source_id) REFERENCES files (id) ON DELETE CASCADE, 
	FOREIGN KEY(space_id) REFERENCES spaces (id) ON DELETE CASCADE, 
	FOREIGN KEY(target_id) REFERENCES files (id) ON DELETE SET NULL
);
CREATE TABLE locks (
	file_id INTEGER NOT NULL, 
	holder VARCHAR(64) NOT NULL, 
	holder_name VARCHAR(255) NOT NULL, 
	acquired_at DATETIME NOT NULL, 
	expires_at DATETIME NOT NULL, 
	PRIMARY KEY (file_id), 
	FOREIGN KEY(file_id) REFERENCES files (id) ON DELETE CASCADE
);
CREATE TABLE looks (
	id INTEGER NOT NULL, 
	space_id INTEGER NOT NULL, 
	folder VARCHAR(1024) NOT NULL, 
	icon VARCHAR(80), 
	color VARCHAR(16), 
	PRIMARY KEY (id), 
	FOREIGN KEY(space_id) REFERENCES spaces (id) ON DELETE CASCADE
);
CREATE TABLE lore_conversations (
	id INTEGER NOT NULL, 
	account_id INTEGER NOT NULL, 
	title_enc TEXT NOT NULL, 
	note_id INTEGER, 
	created_at DATETIME NOT NULL, 
	updated_at DATETIME NOT NULL, 
	PRIMARY KEY (id), 
	FOREIGN KEY(account_id) REFERENCES accounts (id) ON DELETE CASCADE, 
	FOREIGN KEY(note_id) REFERENCES files (id) ON DELETE SET NULL
);
CREATE TABLE lore_messages (
	id INTEGER NOT NULL, 
	conversation_id INTEGER NOT NULL, 
	role VARCHAR(16) NOT NULL, 
	body_enc TEXT NOT NULL, 
	at DATETIME NOT NULL, 
	PRIMARY KEY (id), 
	FOREIGN KEY(conversation_id) REFERENCES lore_conversations (id) ON DELETE CASCADE
);
CREATE TABLE lore_vectors (
	file_id INTEGER NOT NULL, 
	model VARCHAR(200) NOT NULL, 
	source_hash VARCHAR(64) NOT NULL, 
	text_hash VARCHAR(64) NOT NULL, 
	dims INTEGER NOT NULL, 
	vector BLOB NOT NULL, 
	updated_at DATETIME NOT NULL, 
	PRIMARY KEY (file_id), 
	FOREIGN KEY(file_id) REFERENCES files (id) ON DELETE CASCADE
);
CREATE TABLE mcp_keys (
	id INTEGER NOT NULL, 
	account_id INTEGER NOT NULL, 
	name VARCHAR(100) NOT NULL, 
	level VARCHAR(8) NOT NULL, 
	token_hash VARCHAR(64) NOT NULL, 
	prefix VARCHAR(16) NOT NULL, 
	spaces JSON, 
	created_at DATETIME NOT NULL, 
	last_used_at DATETIME, 
	tool_rights JSON, 
	kind VARCHAR(8) NOT NULL, 
	client_id VARCHAR(64), 
	refresh_hash VARCHAR(64), 
	expires_at DATETIME, 
	refresh_old_hash VARCHAR(64), 
	signed_in_at DATETIME, 
	PRIMARY KEY (id), 
	FOREIGN KEY(account_id) REFERENCES accounts (id) ON DELETE CASCADE, 
	UNIQUE (token_hash), 
	UNIQUE (refresh_hash)
);
CREATE TABLE mcp_requests (
	id INTEGER NOT NULL, 
	account_id INTEGER NOT NULL, 
	key_id INTEGER NOT NULL, 
	key_name VARCHAR(100) NOT NULL, 
	tool VARCHAR(64) NOT NULL, 
	arguments TEXT NOT NULL, 
	digest VARCHAR(64) NOT NULL, 
	status VARCHAR(16) NOT NULL, 
	result TEXT NOT NULL, 
	created_at DATETIME NOT NULL, 
	expires_at DATETIME NOT NULL, 
	decided_at DATETIME, 
	PRIMARY KEY (id), 
	FOREIGN KEY(account_id) REFERENCES accounts (id) ON DELETE CASCADE, 
	FOREIGN KEY(key_id) REFERENCES mcp_keys (id) ON DELETE CASCADE
);
CREATE TABLE memberships (
	space_id INTEGER NOT NULL, 
	account_id INTEGER NOT NULL, 
	role VARCHAR(16) NOT NULL, 
	created_at DATETIME NOT NULL, 
	PRIMARY KEY (space_id, account_id), 
	FOREIGN KEY(space_id) REFERENCES spaces (id) ON DELETE CASCADE, 
	FOREIGN KEY(account_id) REFERENCES accounts (id) ON DELETE CASCADE
);
INSERT INTO "memberships" VALUES(1,1,'manage','2026-11-24 19:59:38.238653');
INSERT INTO "memberships" VALUES(1,3,'manage','2026-11-24 19:59:38.504459');
INSERT INTO "memberships" VALUES(1,6,'read','2026-11-24 19:59:38.779019');
INSERT INTO "memberships" VALUES(1,9,'write','2026-11-24 19:59:40.940193');
CREATE TABLE move_job_notes (
	job_id INTEGER NOT NULL, 
	note_id INTEGER NOT NULL, 
	position INTEGER NOT NULL, 
	moved BOOLEAN NOT NULL, 
	links JSON NOT NULL, 
	PRIMARY KEY (job_id, note_id), 
	FOREIGN KEY(job_id) REFERENCES move_jobs (id) ON DELETE CASCADE, 
	FOREIGN KEY(note_id) REFERENCES files (id) ON DELETE CASCADE
);
CREATE TABLE move_jobs (
	id INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, 
	space_id INTEGER NOT NULL, 
	author VARCHAR(64), 
	keys JSON NOT NULL, 
	created_at DATETIME NOT NULL, 
	FOREIGN KEY(space_id) REFERENCES spaces (id) ON DELETE CASCADE
);
PRAGMA writable_schema=ON;
CREATE TABLE notes_seen (
	id INTEGER NOT NULL, 
	account_id INTEGER NOT NULL, 
	file_id INTEGER NOT NULL, 
	seen_at DATETIME NOT NULL, 
	PRIMARY KEY (id), 
	FOREIGN KEY(account_id) REFERENCES accounts (id) ON DELETE CASCADE, 
	FOREIGN KEY(file_id) REFERENCES files (id) ON DELETE CASCADE
);
CREATE TABLE oauth_clients (
	id VARCHAR(64) NOT NULL, 
	name VARCHAR(100) NOT NULL, 
	redirect_uris JSON NOT NULL, 
	created_at DATETIME NOT NULL, 
	last_used_at DATETIME, 
	PRIMARY KEY (id)
);
CREATE TABLE oauth_codes (
	code_hash VARCHAR(64) NOT NULL, 
	client_id VARCHAR(64) NOT NULL, 
	account_id INTEGER NOT NULL, 
	redirect_uri VARCHAR(2048) NOT NULL, 
	challenge VARCHAR(128) NOT NULL, 
	level VARCHAR(8) NOT NULL, 
	spaces JSON, 
	expires_at DATETIME NOT NULL, 
	PRIMARY KEY (code_hash), 
	FOREIGN KEY(client_id) REFERENCES oauth_clients (id) ON DELETE CASCADE, 
	FOREIGN KEY(account_id) REFERENCES accounts (id) ON DELETE CASCADE
);
CREATE TABLE oidc_links (
	id INTEGER NOT NULL, 
	provider_id INTEGER NOT NULL, 
	subject VARCHAR(255) NOT NULL, 
	account_id INTEGER NOT NULL, 
	issuer VARCHAR(500) NOT NULL, 
	email VARCHAR(320), 
	created_at DATETIME NOT NULL, 
	last_used_at DATETIME, 
	PRIMARY KEY (id), 
	UNIQUE (provider_id, subject), 
	UNIQUE (provider_id, account_id), 
	FOREIGN KEY(provider_id) REFERENCES oidc_providers (id) ON DELETE CASCADE, 
	FOREIGN KEY(account_id) REFERENCES accounts (id) ON DELETE CASCADE
);
INSERT INTO "oidc_links" VALUES(1,1,'sub-sam',7,'https://sso.example.com','sam@example.net','2026-11-24 19:59:40.383363',NULL);
INSERT INTO "oidc_links" VALUES(2,1,'sub-robin',8,'https://sso.example.com','robin@example.net','2026-11-24 19:59:40.589581',NULL);
INSERT INTO "oidc_links" VALUES(3,1,'sub-max',9,'https://sso.example.com','max@example.net','2026-11-24 19:59:40.940504',NULL);
CREATE TABLE oidc_providers (
	id INTEGER NOT NULL, 
	slug VARCHAR(40) NOT NULL, 
	label VARCHAR(64) NOT NULL, 
	issuer VARCHAR(500) NOT NULL, 
	client_id VARCHAR(255) NOT NULL, 
	client_secret_enc TEXT NOT NULL, 
	scopes VARCHAR(500) NOT NULL, 
	enabled BOOLEAN NOT NULL, 
	auto_create BOOLEAN NOT NULL, 
	trusts_second_factor BOOLEAN NOT NULL, 
	managed VARCHAR(20) NOT NULL, 
	position INTEGER NOT NULL, 
	redirect_path VARCHAR(300) NOT NULL, 
	registered_redirect VARCHAR(600) DEFAULT '' NOT NULL, 
	created_at DATETIME NOT NULL, 
	PRIMARY KEY (id), 
	UNIQUE (slug)
);
INSERT INTO "oidc_providers" VALUES(1,'sso','SSO','https://sso.example.com','nexlore-bestand','e363405cb5cb2460b01433a636b2854751965f0b160ff6a6ad7f5d35fdbc736d82452c8a4397709976a4','openid profile email',1,1,1,'',0,'','','2026-11-24 19:59:40.079299');
CREATE TABLE plugin_users (
	plugin_id VARCHAR(32) NOT NULL, 
	account_id INTEGER NOT NULL, 
	enabled BOOLEAN NOT NULL, 
	data JSON, 
	PRIMARY KEY (plugin_id, account_id), 
	FOREIGN KEY(plugin_id) REFERENCES plugins (id) ON DELETE CASCADE, 
	FOREIGN KEY(account_id) REFERENCES accounts (id) ON DELETE CASCADE
);
CREATE TABLE plugins (
	id VARCHAR(32) NOT NULL, 
	version VARCHAR(16) NOT NULL, 
	source VARCHAR(8) NOT NULL, 
	approved BOOLEAN NOT NULL, 
	manifest JSON, 
	code TEXT NOT NULL, 
	code_hash VARCHAR(64) NOT NULL, 
	installed_at DATETIME NOT NULL, 
	installed_by VARCHAR(64), 
	PRIMARY KEY (id)
);
CREATE TABLE proposals (
	id INTEGER NOT NULL, 
	account_id INTEGER NOT NULL, 
	space_id INTEGER NOT NULL, 
	file_id INTEGER NOT NULL, 
	base_hash VARCHAR(64) NOT NULL, 
	content BLOB NOT NULL, 
	message VARCHAR(500) NOT NULL, 
	status VARCHAR(12) NOT NULL, 
	created_at DATETIME NOT NULL, 
	decided_at DATETIME, 
	decided_by VARCHAR(255), 
	lore BOOLEAN NOT NULL, 
	PRIMARY KEY (id), 
	FOREIGN KEY(account_id) REFERENCES accounts (id) ON DELETE CASCADE, 
	FOREIGN KEY(space_id) REFERENCES spaces (id) ON DELETE CASCADE, 
	FOREIGN KEY(file_id) REFERENCES files (id) ON DELETE CASCADE
);
CREATE TABLE recent_notes (
	id INTEGER NOT NULL, 
	account_id INTEGER NOT NULL, 
	file_id INTEGER NOT NULL, 
	opened_at DATETIME NOT NULL, 
	PRIMARY KEY (id), 
	FOREIGN KEY(account_id) REFERENCES accounts (id) ON DELETE CASCADE, 
	FOREIGN KEY(file_id) REFERENCES files (id) ON DELETE CASCADE
);
CREATE TABLE settings (
	"key" VARCHAR(64) NOT NULL, 
	value JSON, 
	PRIMARY KEY ("key")
);
INSERT INTO "settings" VALUES('midword_index','"trigram detail=none v1"');
INSERT INTO "settings" VALUES('oidc_list_migrated','true');
INSERT INTO "settings" VALUES('oidc_legacy_anchor','"-"');
INSERT INTO "settings" VALUES('oidc_legacy_fingerprint','"nexoidc-fp2|-|"');
INSERT INTO "settings" VALUES('public_url','"https://lore.example.com"');
INSERT INTO "settings" VALUES('smtp_host','"smtp.example.com"');
INSERT INTO "settings" VALUES('smtp_from','"lore@example.com"');
INSERT INTO "settings" VALUES('api_tokens_allowed','true');
INSERT INTO "settings" VALUES('shares_allowed','true');
CREATE TABLE shares (
	id INTEGER NOT NULL, 
	token VARCHAR(64) NOT NULL, 
	space_id INTEGER NOT NULL, 
	path VARCHAR(1024) NOT NULL, 
	is_folder BOOLEAN NOT NULL, 
	created_by INTEGER, 
	created_at DATETIME NOT NULL, 
	expires_at DATETIME, 
	password_hash VARCHAR(255) NOT NULL, 
	PRIMARY KEY (id), 
	UNIQUE (token), 
	FOREIGN KEY(space_id) REFERENCES spaces (id) ON DELETE CASCADE, 
	FOREIGN KEY(created_by) REFERENCES accounts (id) ON DELETE SET NULL
);
INSERT INTO "shares" VALUES(1,'bestand-jonas-seite-023-festwert',1,'Projekt/Liste.md',0,3,'2026-11-24 19:59:40.006715',NULL,'');
CREATE TABLE space_notices (
	id INTEGER NOT NULL, 
	account_id INTEGER NOT NULL, 
	space_id INTEGER, 
	space_name VARCHAR(255) NOT NULL, 
	kind VARCHAR(24) NOT NULL, 
	role VARCHAR(16) NOT NULL, 
	actor VARCHAR(64) NOT NULL, 
	actor_id INTEGER, 
	subject VARCHAR(64) NOT NULL, 
	created_at DATETIME NOT NULL, 
	done_at DATETIME, 
	PRIMARY KEY (id), 
	FOREIGN KEY(account_id) REFERENCES accounts (id) ON DELETE CASCADE, 
	FOREIGN KEY(space_id) REFERENCES spaces (id) ON DELETE CASCADE, 
	FOREIGN KEY(actor_id) REFERENCES accounts (id) ON DELETE SET NULL
);
INSERT INTO "space_notices" VALUES(1,2,1,'Projekt','invite','write','betrieb',1,'','2026-11-24 19:59:41.605021',NULL);
CREATE TABLE spaces (
	id INTEGER NOT NULL, 
	folder VARCHAR(255) NOT NULL, 
	created_at DATETIME NOT NULL, 
	options JSON, 
	PRIMARY KEY (id), 
	UNIQUE (folder)
);
INSERT INTO "spaces" VALUES(1,'Projekt','2026-11-24 19:59:38.224276',NULL);
CREATE TABLE tags (
	file_id INTEGER NOT NULL, 
	tag_key VARCHAR(255) NOT NULL, 
	tag VARCHAR(255) NOT NULL, 
	pos INTEGER NOT NULL, 
	PRIMARY KEY (file_id, tag_key), 
	FOREIGN KEY(file_id) REFERENCES files (id) ON DELETE CASCADE
);
CREATE TABLE tasks (
	id INTEGER NOT NULL, 
	file_id INTEGER NOT NULL, 
	space_id INTEGER NOT NULL, 
	line INTEGER NOT NULL, 
	raw VARCHAR(4000) NOT NULL, 
	status VARCHAR(12) NOT NULL, 
	mark VARCHAR(4) NOT NULL, 
	text VARCHAR(1000) NOT NULL, 
	due VARCHAR(10), 
	scheduled VARCHAR(10), 
	start VARCHAR(10), 
	completed VARCHAR(10), 
	priority INTEGER NOT NULL, 
	recurrence VARCHAR(200), 
	tags VARCHAR(1000) NOT NULL, 
	tag_keys VARCHAR(1000) NOT NULL, 
	PRIMARY KEY (id), 
	FOREIGN KEY(file_id) REFERENCES files (id) ON DELETE CASCADE, 
	FOREIGN KEY(space_id) REFERENCES spaces (id) ON DELETE CASCADE
);
CREATE TABLE themes (
	id INTEGER NOT NULL, 
	account_id INTEGER NOT NULL, 
	name VARCHAR(80) NOT NULL, 
	colours JSON NOT NULL, 
	shared BOOLEAN NOT NULL, 
	created_at DATETIME NOT NULL, 
	changed_at DATETIME NOT NULL, 
	PRIMARY KEY (id), 
	FOREIGN KEY(account_id) REFERENCES accounts (id) ON DELETE CASCADE
);
CREATE TABLE trash_blobs (
	file_id INTEGER NOT NULL, 
	content BLOB NOT NULL, 
	PRIMARY KEY (file_id), 
	FOREIGN KEY(file_id) REFERENCES files (id) ON DELETE CASCADE
);
CREATE TABLE vault_cursor (
	id INTEGER NOT NULL, 
	last INTEGER NOT NULL, 
	oldest INTEGER NOT NULL, 
	top_id INTEGER NOT NULL, 
	PRIMARY KEY (id)
);
INSERT INTO "vault_cursor" VALUES(1,13,0,3);
CREATE TABLE versions (
	id INTEGER NOT NULL, 
	file_id INTEGER NOT NULL, 
	path VARCHAR(1024) NOT NULL, 
	created_at DATETIME NOT NULL, 
	updated_at DATETIME NOT NULL, 
	source VARCHAR(16) NOT NULL, 
	author VARCHAR(255), 
	session VARCHAR(64), 
	hash VARCHAR(64) NOT NULL, 
	size INTEGER NOT NULL, 
	content BLOB NOT NULL, 
	PRIMARY KEY (id), 
	FOREIGN KEY(file_id) REFERENCES files (id) ON DELETE CASCADE
);
INSERT INTO "versions" VALUES(1,1,'Projekt/Plan.md','2026-11-24 19:59:38.327860','2026-11-24 19:59:38.327860','app','betrieb','tab-bestand01','a4d6cff76a97245a3248fc9faed3840453353ca8141566812497444de0486f0e',35,X'789C535608C849CCE3E2722D2A2E4955704B2C2E2ECD4B5728CBCF55704A2D29CA4C4DD2E30200C6A10B64');
INSERT INTO "versions" VALUES(2,1,'Projekt/Plan.md','2026-11-24 19:59:39.642045','2026-11-24 19:59:39.642045','app','jonas','tab-bestand03','71a3bc8aad4e492e1d5e00b4ad48045bb8745b53c42d26ba2d543848d9dada56',56,X'789C535608C849CCE3E2722D2A2E4955704B2C2E2ECD4B5728CBCF55704A2D29CA4C4DD203C9A51F5E925755A250969FA7E0959F9758ACC705000FE11315');
INSERT INTO "versions" VALUES(3,2,'Projekt/Liste.md','2026-11-24 19:59:39.726082','2026-11-24 19:59:39.726082','app','jonas','tab-bestand03','f99d77d718e71aa079a7f14e5288caf550fcb20844baea8b9cff92750a3128be',20,X'789C5356F0C92C2E49E5E2D255084F2DCAAE4A2D4DE702003B300604');
INSERT INTO "versions" VALUES(4,2,'Projekt/Liste.md','2026-11-24 19:59:41.342296','2026-11-24 19:59:41.342296','app','weg','tab-bestand10','c4a0e687458143c01bd21acc275df6e8cd4f93de14b337edd1e23e52d74d68aa',29,X'789C5356F0C92C2E49E5E2D255084F2DCAAE4A2D4DE7D255F049CD2C492DE202007E5508C0');
CREATE INDEX ix_accounts_calendar_feed_hash ON accounts (calendar_feed_hash);
CREATE INDEX ix_gone_files_space_id ON gone_files (space_id);
CREATE INDEX ix_gone_files_cursor ON gone_files (cursor);
CREATE INDEX ix_files_trash_group ON files (trash_group);
CREATE INDEX files_space_hash ON files (space_id, hash);
CREATE INDEX files_space_path_key ON files (space_id, path_key);
CREATE UNIQUE INDEX files_live_path ON files (path) WHERE deleted_at IS NULL;
CREATE INDEX files_deleted ON files (deleted_at);
CREATE INDEX ix_files_cursor ON files (cursor);
CREATE INDEX files_space_name ON files (space_id, name_key);
CREATE INDEX files_owner ON files (owner);
CREATE INDEX ix_auth_sessions_account_id ON auth_sessions (account_id);
CREATE INDEX ix_oidc_links_account_id ON oidc_links (account_id);
CREATE INDEX ix_oidc_links_provider_id ON oidc_links (provider_id);
CREATE INDEX ix_memberships_account_id ON memberships (account_id);
CREATE INDEX ix_space_notices_account_id ON space_notices (account_id);
CREATE INDEX ix_shares_space_id ON shares (space_id);
CREATE UNIQUE INDEX looks_space_folder ON looks (space_id, folder);
CREATE INDEX ix_mcp_keys_account_id ON mcp_keys (account_id);
CREATE INDEX ix_mcp_keys_client_id ON mcp_keys (client_id);
CREATE INDEX ix_mcp_keys_refresh_old_hash ON mcp_keys (refresh_old_hash);
CREATE INDEX ix_api_tokens_account_id ON api_tokens (account_id);
CREATE INDEX ix_favorites_account_id ON favorites (account_id);
CREATE UNIQUE INDEX favorites_account_path ON favorites (account_id, path);
CREATE INDEX ix_themes_shared ON themes (shared);
CREATE INDEX ix_themes_account_id ON themes (account_id);
CREATE INDEX ix_css_snippets_account_id ON css_snippets (account_id);
CREATE INDEX ix_ai_events_at ON ai_events (at);
CREATE INDEX ix_ai_events_account_id ON ai_events (account_id);
CREATE INDEX ix_app_devices_account_id ON app_devices (account_id);
CREATE INDEX ix_app_pairings_account_id ON app_pairings (account_id);
CREATE INDEX ix_app_pairings_code_hash ON app_pairings (code_hash);
CREATE INDEX links_space_pair ON links (space_id, source_id, target_id);
CREATE INDEX links_across_in ON links (target_space_id, target_id, source_id, space_id) WHERE target_space_id IS NOT NULL;
CREATE INDEX ix_links_source_id ON links (source_id);
CREATE INDEX links_across_out ON links (space_id, source_id, target_id, target_space_id) WHERE target_space_id IS NOT NULL;
CREATE INDEX links_via_key ON links (via, target_key);
CREATE INDEX ix_links_target_id ON links (target_id);
CREATE INDEX links_space_target_key ON links (space_id, target_key);
CREATE INDEX tags_key ON tags (tag_key);
CREATE INDEX tasks_space_status_due ON tasks (space_id, status, due);
CREATE INDEX ix_tasks_file_id ON tasks (file_id);
CREATE INDEX tasks_space_status_scheduled ON tasks (space_id, status, scheduled);
CREATE INDEX graph_nodes_tile ON graph_nodes (space_id, cloud, level, x, y);
CREATE INDEX ix_graph_nodes_group_id ON graph_nodes (group_id);
CREATE INDEX versions_updated ON versions (updated_at);
CREATE INDEX versions_file_time ON versions (file_id, created_at);
CREATE INDEX ix_comments_space_id ON comments (space_id);
CREATE INDEX ix_comments_file_id ON comments (file_id);
CREATE INDEX ix_comments_thread_id ON comments (thread_id);
CREATE INDEX ix_notes_seen_file_id ON notes_seen (file_id);
CREATE INDEX ix_notes_seen_account_id ON notes_seen (account_id);
CREATE UNIQUE INDEX notes_seen_account_file ON notes_seen (account_id, file_id);
CREATE INDEX proposals_file_status ON proposals (file_id, status);
CREATE INDEX ix_proposals_space_id ON proposals (space_id);
CREATE INDEX ix_proposals_account_id ON proposals (account_id);
CREATE INDEX ix_recent_notes_file_id ON recent_notes (file_id);
CREATE UNIQUE INDEX recent_account_file ON recent_notes (account_id, file_id);
CREATE INDEX ix_recent_notes_account_id ON recent_notes (account_id);
CREATE INDEX ix_lore_conversations_account_id ON lore_conversations (account_id);
CREATE INDEX ix_lore_conversations_updated_at ON lore_conversations (updated_at);
CREATE INDEX ix_lore_conversations_note_id ON lore_conversations (note_id);
CREATE INDEX ix_drafts_account_id ON drafts (account_id);
CREATE INDEX ix_drafts_space_id ON drafts (space_id);
CREATE INDEX ix_drafts_file_id ON drafts (file_id);
CREATE INDEX ix_mcp_requests_account_id ON mcp_requests (account_id);
CREATE INDEX ix_mcp_requests_status ON mcp_requests (status);
CREATE INDEX ix_mcp_requests_key_id ON mcp_requests (key_id);
CREATE INDEX ix_device_bases_file_id ON device_bases (file_id);
CREATE INDEX ix_app_ops_created_at ON app_ops (created_at);
CREATE INDEX ix_lore_messages_conversation_id ON lore_messages (conversation_id);
PRAGMA writable_schema=OFF;
DELETE FROM "sqlite_sequence";
COMMIT;